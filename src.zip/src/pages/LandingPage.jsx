import AboutPage from "./AboutPage";
import ProjectsPage from "./ProjectsPage";
import WorkExperiencePage from "./WorkExperiencePage";
import ContactPage from "./ContactPage";

function LandingPage() {
  return (
    <div className="">
      <div className="">
        <h2 className="text-xl font-semibold">Landing Page</h2>
        <AboutPage />
        <ProjectsPage />
        <WorkExperiencePage />
        
      </div>
    </div>
  );
}

export default LandingPage;
